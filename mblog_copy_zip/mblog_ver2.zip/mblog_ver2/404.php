<?php get_header(); ?>

<div class="col-xs-12 wrap">
	<h2 class="text-center">URLが間違っている or 記事が削除された or 非公開です〜<(_ _)></h2>
</div>

<?php get_footer(); ?>