				</div> <!-- end of articleBody -->
			</section>
		</article>
		<?php
			// LPページ用のカスタマイズ
			if ( is_page_template( 'page_lp.php' ) ) {
			} else {
				get_sidebar();
			}
		?>
	</div> <!-- end onf row -->
</div> <!-- end onf container -->

</main><!-- end main -->

<!-- パンくずリスト -->
<?php wp_reset_query(); ?>
<?php if ( !is_home() && !is_category() && !is_tag() && !is_search()  ) { ?>
<?php get_template_part( 'breadcrumb' ); ?>
<?php } else { ?>
<?php } ?>
<!-- /パンくずリスト -->

<footer id="footer" role="contentinfo" itemscope="itemscope" itemtype="http://schema.org/WPFooter">

	<div class="container">
		<div class="row">
			<div class="col-xs-12 col-sm-4">
				<h4>About me!</h4>
				<hr>
				<div style="clear:both"></div>
				<p>ランサーズでPythonのDjango案件受注経験あり| web系のプログラミング情報をつぶやきます | 20歳 専門学校3年生 | プログラミング挫折→ブログ書く→挫折→ブログ再開→ブログで最高月収益4桁&最高月間3000pv達成 | 実は仮想通貨でお金を5倍増やした経験もあります | 家に引きこもって生きる</p>
			</div>

			<div class="col-xs-12 col-sm-4">
				<h4>information</h4>
				<hr>
				<div style="clear:both"></div>
				<ul class="list-unstyled">
					<li><a href="https://sushiringblog.com/profile" target="new" rel="nofollow">はるのプロフィール【自己紹介】</a></li>
					<li><a href="https://sushiringblog.com/contact" target="new" rel="nofollow">お問い合わせ</a></li>
					<li><a href="https://sushiringblog.com/sitemap" target="new" rel="nofollow">サイトマップ</a></li>
					<li><a href="https://sushiringblog.com/portfolio-page" target="new" rel="nofollow">ポートフォリオ</a></li>
					<li><a href="https://sushiringblog.com/privacypolicy" target="new" rel="nofollow">プライバシーポリシー</a></li>
				</ul>
			</div>

			<div class="col-xs-12 col-sm-4">
				<h4>Twitter</h4>
				<hr class="twitter">
				<div style="clear:both"></div>
				<a class="twitter-timeline" data-lang="ja" data-height="570" data-theme="light" href="https://twitter.com/haruki_otsuka?ref_src=twsrc%5Etfw">Tweets by haruki_otsuka</a> <script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
			</div>
		</div>
	</div>

	<div class="container-fluid credit">
		<div class="row">
			<p class="col-xs-12 text-center">Copyright - <a href="https://sushiringblog.com/">Haruki Otsuka</a>, 2019-2021 All Rights Reserved.</p>
		</div>
	</div>

</footer>
<!-- heatmapのトラッキング -->
<script>
(function(h,e,a,t,m,p) {
m=e.createElement(a);m.async=!0;m.src=t;
p=e.getElementsByTagName(a)[0];p.parentNode.insertBefore(m,p);
})(window,document,'script','https://u.heatmap.it/log.js');
</script>
<!-- heatmapのトラッキング -->
</body>

<script src="<?php echo get_template_directory_uri(); ?>/scripts/min/myscripts-min.js"></script>
<script type="text/javascript">
function downloadJSAtOnload() {
	var element = document.createElement("script");
	element.src = "<?php echo get_template_directory_uri(); ?>/scripts/min/defer-min.js";
	document.body.appendChild(element);
}
if (window.addEventListener)
	window.addEventListener("load", downloadJSAtOnload, false);
else if (window.attachEvent)
	window.attachEvent("onload", downloadJSAtOnload);
else window.onload = downloadJSAtOnload;
</script>

<?php wp_footer(); ?>
</html>