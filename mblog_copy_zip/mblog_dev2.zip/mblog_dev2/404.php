<?php get_header(); ?>

<div class="col-xs-12 wrap">
	<h2 class="text-center">記事が削除されています</h2>
</div>

<?php get_footer(); ?>