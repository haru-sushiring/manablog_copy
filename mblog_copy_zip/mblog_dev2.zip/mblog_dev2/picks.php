<div class="col-xs-12 picks">

	<div class="col-xs-12 col-sm-4 wrap ">
		<div itemscope="" itemtype="http://schema.org/ImageObject" class="thumbnail">
			<a style="background-image:url(https://sushiringblog.com/wp-content/uploads/2020/12/stop-scaled.jpg)" itemprop="url" class="thumbnail-img"></a>
		</div>
		<h2 class="title" itemprop="name headline">
			<a href="https://sushiringblog.com/stop-playing-social-games" itemprop="url">ソシャゲをやめる方法【ソシャゲ歴7年の私でもやめられた】</a>
		</h2>
		<div class="readmore"><a href="https://sushiringblog.com/stop-playing-social-games">READ MORE</a></div>
	</div>
	<div class="col-xs-12 col-sm-4 wrap center">
		<div itemscope="" itemtype="http://schema.org/ImageObject" class="thumbnail">
			<a style="background-image:url(https://sushiringblog.com/wp-content/uploads/2020/01/AdobeStock_293662777-scaled.jpeg)" itemprop="url" class="thumbnail-img"></a>
		</div>
		<h2 class="title" itemprop="name headline">
			<a href="https://sushiringblog.com/university-or-professional-training-college" itemprop="url">大学に全落ちしたら専門学校に行くべきなのか 【違う道もあります】</a>
		</h2>
		<div class="readmore"><a href="https://sushiringblog.com/university-or-professional-training-college">READ MORE</a></div>
	</div>
	<div class="col-xs-12 col-sm-4 wrap ">
		<div itemscope="" itemtype="http://schema.org/ImageObject" class="thumbnail">
			<a style="background-image:url(https://sushiringblog.com/wp-content/uploads/2021/05/micheile-henderson-ZVprbBmT8QA-unsplash-scaled.jpeg)" itemprop="url" class="thumbnail-img"></a>
		</div>
		<h2 class="title" itemprop="name headline">
			<a href="https://sushiringblog.com/virtual-currency-exchange" itemprop="url">投資家の私がおすすめする仮想通貨取引所(3選)</a>
		</h2>
		<div class="readmore"><a href="https://sushiringblog.com/virtual-currency-exchange">READ MORE</a></div>
	</div>

</div>