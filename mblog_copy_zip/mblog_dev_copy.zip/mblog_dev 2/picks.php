<div class="col-xs-12 picks">

	<div class="col-xs-12 col-sm-4 wrap">
		<div itemscope="" itemtype="http://schema.org/ImageObject" class="thumbnail">
			<a style="background-image:url(http://manabubb.xsrv.jp/manablog/wp-content/uploads/2019/10/top_001.jpg" itemprop="url" class="thumbnail-img"></a>
		</div>
		<h2 class="title" itemprop="name headline">
			<a href="http://manabubb.xsrv.jp/manablog/pick01/"  itemprop="url">ピックアップ記事の１本目<br>オススメ記事の１本目がこちらです</a>
		</h2>
		<div class="readmore"><a href="http://manabubb.xsrv.jp/manablog/pick01/">READ MORE</a></div>
	</div>

	<div class="col-xs-12 col-sm-4 wrap center">
		<div itemscope="" itemtype="http://schema.org/ImageObject" class="thumbnail">
			<a style="background-image:url(https://manablog.org/wp-content/uploads/2019/05/shutterstock_1349672450.jpg" itemprop="url" class="thumbnail-img"></a>
		</div>
		<h2 class="title" itemprop="name headline">
			<a href="http://manabubb.xsrv.jp/manablog/pick02/"  itemprop="url">ピックアップ記事の２本目<br>オススメ記事の２本目がこちらです</a>
		</h2>
		<div class="readmore"><a href="http://manabubb.xsrv.jp/manablog/pick02/">READ MORE</a></div>
	</div>

	<div class="col-xs-12 col-sm-4 wrap">
		<div itemscope="" itemtype="http://schema.org/ImageObject" class="thumbnail">
			<a style="background-image:url(http://manabubb.xsrv.jp/manablog/wp-content/uploads/2019/10/top_003.jpg" itemprop="url" class="thumbnail-img"></a>
		</div>
		<h2 class="title" itemprop="name headline">
			<a href="http://manabubb.xsrv.jp/manablog/pick03/"  itemprop="url">ピックアップ記事の３本目<br>オススメ記事の３本目がこちらです</a>
		</h2>
		<div class="readmore"><a href="http://manabubb.xsrv.jp/manablog/pick03/">READ MORE</a></div>
	</div>

</div>


